# Firmware

[English](README.md) | [简体中文](README_ZH.md)

Firmware for ESP32-C6-Touch-AMOLED-1.32. Each BIN is a merged image flashed at `0x0`; the date or upstream version in its file name identifies the version.

| File | Purpose |
| --- | --- |
| [ESP32-C6-Touch-AMOLED-1.32_FactoryOnly_20251103.bin](ESP32-C6-Touch-AMOLED-1.32_FactoryOnly_20251103.bin) | Factory firmware, restores the out-of-box demo |
| [ESP32-C6-Touch-AMOLED-1.32_XiaoZhi_v2.0.4.bin](ESP32-C6-Touch-AMOLED-1.32_XiaoZhi_v2.0.4.bin) | Xiaozhi AI firmware, version 2.0.4 |

Run these commands in this directory to restore the factory firmware, replacing `<PORT>` with the board's serial port. Erasing flash removes existing settings and user data.

```bash
python -m pip install esptool
esptool.py --chip esp32c6 --port <PORT> erase_flash
esptool.py --chip esp32c6 --port <PORT> write_flash 0x0 ESP32-C6-Touch-AMOLED-1.32_FactoryOnly_20251103.bin
```

To install Xiaozhi AI, follow the same steps and replace the BIN file name in the final command with `ESP32-C6-Touch-AMOLED-1.32_XiaoZhi_v2.0.4.bin`.
