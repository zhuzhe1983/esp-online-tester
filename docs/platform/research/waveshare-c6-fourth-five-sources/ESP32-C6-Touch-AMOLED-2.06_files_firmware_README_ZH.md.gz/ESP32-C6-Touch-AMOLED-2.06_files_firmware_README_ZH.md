# 工厂固件

[English](README.md)

| 文件 | 用途 |
| --- | --- |
| [ESP32-C6-Touch-AMOLED-2.06_FactoryOnly_20261029.bin](ESP32-C6-Touch-AMOLED-2.06_FactoryOnly_20261029.bin) | 2026-10-29 出厂恢复固件，从 `0x0` 烧录。 |
| [ESP32-C6-Touch-AMOLED-2.06-xiaozhi-251028.bin](ESP32-C6-Touch-AMOLED-2.06-xiaozhi-251028.bin) | 此前提供的小智镜像。 |

烧录前：

- 备份必须保留的设备专用数据。
- 确认开发板型号和硬件版本。
- 使用与该镜像对应的产品文档所给烧录偏移和流程；不要从源码构建制品推断。
- 不要把该二进制与其他构建的 bootloader 或分区文件混用。

GitHub Actions 有意把本目录排除在 ESP-IDF 和 Arduino 源码发现之外。成功的
CI 源码构建会生成独立、可追溯的 ZIP，并附带自己的清单和烧录命令。

工厂固件与源码构建固件的区别见[固件指南](../docs/firmware_ZH.md)。

## 更新工厂镜像

工厂二进制替换属于发布操作。请在 Pull Request 中记录其来源、预期硬件版本、
烧录流程、校验值和用户可见版本。绝不能使用无关的本地构建覆盖现有镜像。
