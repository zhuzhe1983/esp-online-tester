# CH32V003 IO and ADC

[English](ch32v003.md) | [简体中文](ch32v003_ZH.md)

The onboard CH32V003 firmware exposes I2C address 0x24 on SDA GPIO6 / SCL GPIO7. Keep that firmware installed.

| Pin / register | Board purpose |
| --- | --- |
| EXIO0 | CST3530 reset |
| EXIO1 | ST7789 reset |
| EXIO2 | Reserved; not exercised |
| EXIO3 | Speaker amplifier enable |
| EXIO4 / EXIO5 | SHTC3 interface; not test outputs |
| EXIO6 / EXIO7 | General IO on the header |
| Register 0x05 | Backlight PWM, 0–255 |
| Register 0x06 | Battery ADC, two bytes, low byte first |

The battery example averages eight 10-bit samples. Nominal voltage is `raw × 3.3 / 1023 × 3`, using the schematic's 200 kΩ / 100 kΩ divider. Reference, divider and ADC tolerances affect accuracy; the value is not a battery percentage.

Use individual peripheral initializers for basic examples. The CH32V003 driver's first initialization restores its default IO registers; LCD/touch reset and amplifier configuration are applied by their respective BSP functions.
