#include <Arduino.h>
#include <Wire.h>
#include <LovyanGFX.hpp>

// 1: three-image swipe album; 0: ESP-IDF-style color and touch test
#ifndef DEMO_IMAGE_ALBUM
#define DEMO_IMAGE_ALBUM 0
#endif

static constexpr int LCD_W = 240;
static constexpr int LCD_H = 284;
static constexpr int LCD_SCLK_PIN = 1;
static constexpr int LCD_MOSI_PIN = 2;
static constexpr int LCD_DC_PIN = 3;
static constexpr int LCD_CS_PIN = 5;
static constexpr int LCD_RST_PIN = 4;
static constexpr int LCD_BL_PIN = 24;
static constexpr int TOUCH_SDA_PIN = 25;
static constexpr int TOUCH_SCL_PIN = 22;
static constexpr int TOUCH_RST_PIN = 10;
static constexpr int TOUCH_INT_PIN = 11;
static constexpr uint8_t TOUCH_ADDR = 0x15;

class LGFX : public lgfx::LGFX_Device {
  lgfx::Panel_ST7789 panel;
  lgfx::Bus_SPI bus;
public:
  LGFX() {
    auto b = bus.config();
    b.spi_host = SPI2_HOST;
    b.spi_mode = 0;
    b.freq_write = 40000000;
    b.pin_sclk = LCD_SCLK_PIN;
    b.pin_mosi = LCD_MOSI_PIN;
    b.pin_miso = -1;
    b.pin_dc = LCD_DC_PIN;
    bus.config(b);
    panel.setBus(&bus);
    auto p = panel.config();
    p.pin_cs = LCD_CS_PIN;
    p.pin_rst = LCD_RST_PIN;
    p.panel_width = LCD_W;
    p.panel_height = LCD_H;
    p.offset_x = 0;
    p.offset_y = 0;
    p.invert = true;
    p.rgb_order = false;
    p.readable = false;
    panel.config(p);
    setPanel(&panel);
  }
};

LGFX lcd;

extern const uint8_t image1_map[] PROGMEM;
extern const uint8_t image2_map[] PROGMEM;
extern const uint8_t image3_map[] PROGMEM;
static const uint8_t *const images[] = {image1_map, image2_map, image3_map};

// CST816S frame: gesture, finger count, X high, X low, Y high, Y low.
static bool readTouch(int16_t &x, int16_t &y) {
  Wire.beginTransmission(TOUCH_ADDR);
  Wire.write(0x01);
  if (Wire.endTransmission(false) != 0) return false;
  if (Wire.requestFrom(TOUCH_ADDR, (uint8_t)6) != 6) return false;

  (void)Wire.read();
  uint8_t points = Wire.read();
  uint8_t xh = Wire.read();
  uint8_t xl = Wire.read();
  uint8_t yh = Wire.read();
  uint8_t yl = Wire.read();
  if (points == 0) return false;

  x = ((xh & 0x0F) << 8) | xl;
  y = ((yh & 0x0F) << 8) | yl;
  return x < LCD_W && y < LCD_H;
}

static void drawImage(uint8_t index) {
  uint16_t rows[LCD_W * 8];
  const uint8_t *src = images[index];
  lcd.startWrite();
  for (int y = 0; y < LCD_H; y += 8) {
    int lines = min(8, LCD_H - y);
    memcpy_P(rows, src + y * LCD_W * 2, lines * LCD_W * 2);
    lcd.pushImage(0, y, LCD_W, lines, rows);
  }
  lcd.endWrite();
}

static void initTouch() {
  pinMode(TOUCH_RST_PIN, OUTPUT);
  digitalWrite(TOUCH_RST_PIN, LOW);
  delay(10);
  digitalWrite(TOUCH_RST_PIN, HIGH);
  delay(50);
  pinMode(TOUCH_INT_PIN, INPUT_PULLUP);
  Wire.begin(TOUCH_SDA_PIN, TOUCH_SCL_PIN, 400000);
}

void setup() {
  Serial.begin(115200);
  pinMode(LCD_BL_PIN, OUTPUT);
  digitalWrite(LCD_BL_PIN, HIGH);
  initTouch();
  lcd.init();
  lcd.setRotation(0);
  lcd.setSwapBytes(true);

#if DEMO_IMAGE_ALBUM
  drawImage(0);
#else
  lcd.fillScreen(TFT_BLACK);
#endif
}

void loop() {
#if DEMO_IMAGE_ALBUM
  static uint8_t current = 0;
  static int16_t startX = 0;
  static int16_t lastX = 0;
  static bool wasTouched = false;
  int16_t x, y;
  bool touched = readTouch(x, y);

  if (touched) {
    if (!wasTouched) startX = x;
    lastX = x;
  } else if (wasTouched && abs(lastX - startX) > 30) {
    current = (lastX < startX) ? (current + 1) % 3 : (current + 2) % 3;
    drawImage(current);
  }
  wasTouched = touched;
  delay(10);
#else
  static const uint16_t colors[] = {TFT_RED, TFT_GREEN, TFT_BLUE, TFT_YELLOW, TFT_WHITE};
  for (uint8_t i = 0; i < 5; ++i) {
    lcd.fillScreen(colors[i]);
    delay(2000);
  }

  int16_t lastX = -1;
  int16_t lastY = -1;
  while (true) {
    int16_t x, y;
    if (readTouch(x, y)) {
      x = constrain(x, 2, LCD_W - 3);
      y = constrain(y, 2, LCD_H - 3);
      if (lastX >= 0 && lastY >= 0) {
        // ESP-IDF draws a 4x4 touch marker. Paint a 4x4 marker at
        // each interpolated point so fast movement does not leave gaps.
        int dx = x - lastX;
        int dy = y - lastY;
        int steps = max(abs(dx), abs(dy));
        for (int i = 1; i <= steps; ++i) {
          int px = lastX + dx * i / steps;
          int py = lastY + dy * i / steps;
          lcd.fillRect(px - 2, py - 2, 4, 4, TFT_RED);
        }
      } else {
        lcd.fillRect(x - 2, y - 2, 4, 4, TFT_RED);
      }
      lastX = x;
      lastY = y;
    } else {
      lastX = -1;
      lastY = -1;
    }
    delay(10);
  }
#endif
}
