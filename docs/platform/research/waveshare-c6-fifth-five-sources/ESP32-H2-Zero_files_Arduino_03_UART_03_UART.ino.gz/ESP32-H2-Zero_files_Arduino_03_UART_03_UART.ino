/**
 ******************************************************************************
 * @file     05_UART.ino
 * @brief    ESP32-H2-Zero UART loopback example over USB Serial/JTAG
 * @version  V1.1
 * @date     2026-08-05
 ******************************************************************************
 * Features:
 * 1. ESP32-H2-Zero has no USB-UART bridge (no CH343), so use `Serial`,
 *    which maps to the chip's built-in USB Serial/JTAG (CDC).
 * 2. Hardware UART pins on this board are TX=23, RX=24; use Serial1 with
 *    those pins only when connecting an external USB-TTL adapter.
 * 3. Echo back all received bytes over USB Serial.
 * 4. Print a heartbeat every 10 seconds to verify the link.
 ******************************************************************************
 */

#include <Arduino.h>

#define RX_PIN 24
#define TX_PIN 23
#define BAUDRATE 115200

void setup() {
  Serial.begin(BAUDRATE);
  delay(200);
  Serial.println("USB Serial/JTAG ready. TX:23, RX:24, baud:115200");
  // Hardware UART option (external USB-TTL on TX=23/RX=24):
  // Serial1.begin(BAUDRATE, SERIAL_8N1, RX_PIN, TX_PIN);
}

void loop() {
  while (Serial.available() > 0) {
    Serial.write(Serial.read());
  }

  static uint32_t lastHeartbeat = 0;
  if (millis() - lastHeartbeat >= 10000) {
    lastHeartbeat = millis();
    Serial.println("Heartbeat: 10s");
  }

  delay(1);
}
