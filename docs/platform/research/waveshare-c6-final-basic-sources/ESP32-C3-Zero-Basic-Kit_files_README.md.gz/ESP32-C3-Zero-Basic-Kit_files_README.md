# ESP32-C3-Zero-Basic-Kit

[中文](README_ZH.md)

This repository contains example programs for the [ESP32-C3-Zero-Basic-Kit](https://www.waveshare.com/esp32-xx-basic-kit.htm?sku=33358).

We are dedicated to providing detailed and easy-to-understand open-source hardware tutorials for developers and electronics enthusiasts, helping you quickly get started with Waveshare products and deeply understand their features. We hope these codes provide reference and convenience for your project exploration.

[![ESP32-C3-Zero-Basic-Kit](https://www.waveshare.com/img/devkit/ESP32-XX-Basic-Kit/ESP32-XX-Basic-Kit-Acce-details-1.jpg)](https://www.waveshare.com/esp32-xx-basic-kit.htm?sku=33358)

## Tutorial Resources

- **Documentation Tutorial**: https://docs.waveshare.com/ESP32-Tutorials-Intro

## Examples Included

- [Arduino](Arduino)
- [MicroPython](MicroPython)
- [ESP-IDF](ESP-IDF)