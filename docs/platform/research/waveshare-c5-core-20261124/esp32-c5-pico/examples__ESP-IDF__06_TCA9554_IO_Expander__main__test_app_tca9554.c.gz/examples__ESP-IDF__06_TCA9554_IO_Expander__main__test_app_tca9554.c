/*
 * SPDX-FileCopyrightText: 2024 Espressif Systems (Shanghai) CO LTD
 *
 * SPDX-License-Identifier: Apache-2.0
 */

#include <stdio.h>
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include "esp_system.h"
#include "esp_log.h"
#include "driver/i2c_master.h"
#include "esp_io_expander_tca9554.h"

// Pinout for ESP32-S3-LCD-Ev-Board
#define I2C_MASTER_SCL_IO   24          /*!< gpio number for I2C master clock */
#define I2C_MASTER_SDA_IO   23          /*!< gpio number for I2C master data  */
#define I2C_MASTER_NUM      I2C_NUM_0   /*!< I2C port number for master dev */
#define I2C_ADDRESS         ESP_IO_EXPANDER_I2C_TCA9554_ADDRESS_000
/*!< I2C address of slave dev */

#define TEST_LOOP_DELAY_MS  500         /*!< Delay between output toggles */
#define TEST_OUTPUT_PINS    (IO_EXPANDER_PIN_NUM_0 | IO_EXPANDER_PIN_NUM_1)
#define TEST_INPUT_PINS     (IO_EXPANDER_PIN_NUM_2 | IO_EXPANDER_PIN_NUM_3)

static const char *TAG = "tca9554 demo";
static esp_io_expander_handle_t io_expander = NULL;
static i2c_master_bus_handle_t i2c_handle = NULL;

/**
 * @brief Initialize I2C master bus
 */
static void i2c_bus_init(void)
{
    const i2c_master_bus_config_t bus_config = {
        .i2c_port = I2C_MASTER_NUM,
        .sda_io_num = I2C_MASTER_SDA_IO,
        .scl_io_num = I2C_MASTER_SCL_IO,
        .clk_source = I2C_CLK_SRC_DEFAULT,
        .glitch_ignore_cnt = 7,
        .flags.enable_internal_pullup = 1,
    };

    esp_err_t ret = i2c_new_master_bus(&bus_config, &i2c_handle);
    if (ret != ESP_OK) {
        ESP_LOGE(TAG, "I2C install failed: %s", esp_err_to_name(ret));
        abort();
    }
    ESP_LOGI(TAG, "I2C bus initialized");
}

/**
 * @brief Deinitialize I2C master bus
 */
static void i2c_bus_deinit(void)
{
    esp_err_t ret = i2c_del_master_bus(i2c_handle);
    if (ret != ESP_OK) {
        ESP_LOGE(TAG, "I2C uninstall failed: %s", esp_err_to_name(ret));
    } else {
        ESP_LOGI(TAG, "I2C bus deinitialized");
    }
}

/**
 * @brief Create TCA9554 device on I2C bus
 */
static void i2c_dev_tca9554_init(void)
{
    esp_err_t ret = esp_io_expander_new_i2c_tca9554(i2c_handle, I2C_ADDRESS, &io_expander);
    if (ret != ESP_OK) {
        ESP_LOGE(TAG, "TCA9554 create failed: %s", esp_err_to_name(ret));
        abort();
    }
    ESP_LOGI(TAG, "TCA9554 created at address 0x%02X", I2C_ADDRESS);
}

/**
 * @brief Delete TCA9554 device
 */
static void i2c_dev_tca9554_deinit(void)
{
    esp_err_t ret = esp_io_expander_del(io_expander);
    if (ret != ESP_OK) {
        ESP_LOGE(TAG, "TCA9554 delete failed: %s", esp_err_to_name(ret));
    } else {
        ESP_LOGI(TAG, "TCA9554 deleted");
    }
}

void app_main(void)
{
    // Print fancy header (optional)
    printf("\n");
    printf(" ________   ______    ______    ______   _______   _______  __    __    ___   ______   ___\r\n");
    printf("|        \\ /      \\  /      \\  /      \\ |       \\ |       \\|  \\  |  \\  /   \\ /      \\ |   \\\r\n");
    printf(" \\$$$$$$$$|  $$$$$$\\|  $$$$$$\\|  $$$$$$\\| $$$$$$$ | $$$$$$$| $$  | $$ /  $$$|  $$$$$$\\ \\$$$\\\r\n");
    printf("   | $$   | $$   \\$$| $$__| $$| $$__/ $$| $$____  | $$____ | $$__| $$|  $$  | $$__| $$   \\$$\\\r\n");
    printf("   | $$   | $$      | $$    $$ \\$$    $$| $$    \\ | $$    \\| $$    $$| $$   | $$    $$   | $$\r\n");
    printf("   | $$   | $$   __ | $$$$$$$$ _\\$$$$$$$ \\$$$$$$$\\ \\$$$$$$$\\\\$$$$$$$$| $$   | $$$$$$$$   | $$\r\n");
    printf("   | $$   | $$__/  \\| $$  | $$|  \\__/ $$|  \\__| $$|  \\__| $$     | $$ \\$$\\_ | $$  | $$ _/  $$\r\n");
    printf("   | $$    \\$$    $$| $$  | $$ \\$$    $$ \\$$    $$ \\$$    $$     | $$  \\$$ \\| $$  | $$|   $$\r\n");
    printf("    \\$$     \\$$$$$$  \\$$   \\$$  \\$$$$$$   \\$$$$$$   \\$$$$$$       \\$$   \\$$$ \\$$   \\$$ \\$$$\r\n");
    printf("\n");

    ESP_LOGI(TAG, "Starting TCA9554 output toggle demo");

    // Initialize hardware
    i2c_bus_init();
    i2c_dev_tca9554_init();

    // Configure pins: TEST_OUTPUT_PINS as output, TEST_INPUT_PINS as input
    esp_err_t ret;
    ret = esp_io_expander_set_dir(io_expander, TEST_OUTPUT_PINS, IO_EXPANDER_OUTPUT);
    if (ret != ESP_OK) {
        ESP_LOGE(TAG, "Failed to set output dir: %s", esp_err_to_name(ret));
        goto cleanup;
    }
    ret = esp_io_expander_set_dir(io_expander, TEST_INPUT_PINS, IO_EXPANDER_INPUT);
    if (ret != ESP_OK) {
        ESP_LOGE(TAG, "Failed to set input dir: %s", esp_err_to_name(ret));
        goto cleanup;
    }

    // Print initial state
    ESP_LOGI(TAG, "Initial pin configuration and levels:");
    ret = esp_io_expander_print_state(io_expander);
    if (ret != ESP_OK) {
        ESP_LOGE(TAG, "Failed to print state: %s", esp_err_to_name(ret));
    }

    // Main loop: toggle output pins every TEST_LOOP_DELAY_MS
    int level = 0;
    while (1) {
        // Set output pins to current level
        ret = esp_io_expander_set_level(io_expander, TEST_OUTPUT_PINS, level);
        if (ret != ESP_OK) {
            ESP_LOGE(TAG, "Failed to set level: %s", esp_err_to_name(ret));
            break;
        }

        ESP_LOGI(TAG, "Output pins set to %d", level);
        
        // Optionally read and show input pin levels
        uint32_t input_level_mask = 0;
        ret = esp_io_expander_get_level(io_expander, TEST_INPUT_PINS, &input_level_mask);
        if (ret == ESP_OK) {
            ESP_LOGI(TAG, "Input pins level mask: 0x%02" PRIX32, input_level_mask);
        }

        // Toggle level for next iteration
        level = !level;

        // Delay before next toggle
        vTaskDelay(pdMS_TO_TICKS(TEST_LOOP_DELAY_MS));
    }

cleanup:
    ESP_LOGE(TAG, "Demo stopped due to error, cleaning up...");
    i2c_dev_tca9554_deinit();
    i2c_bus_deinit();
    vTaskDelay(10); // Allow FreeRTOS to release resources
}