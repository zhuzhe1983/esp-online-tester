#include <Arduino.h>
#include <Wire.h>

static constexpr uint8_t I2C_SDA_PIN = 23;
static constexpr uint8_t I2C_SCL_PIN = 24;
static constexpr uint8_t TCA9554_ADDRESS = 0x20;

static constexpr uint8_t REG_INPUT = 0x00;
static constexpr uint8_t REG_OUTPUT = 0x01;
static constexpr uint8_t REG_POLARITY = 0x02;
static constexpr uint8_t REG_CONFIGURATION = 0x03;

static constexpr uint8_t ACCESSIBLE_EXT_IO_COUNT = 6;

bool writeRegister(uint8_t reg, uint8_t value) {
  Wire.beginTransmission(TCA9554_ADDRESS);
  Wire.write(reg);
  Wire.write(value);
  return Wire.endTransmission() == 0;
}

bool readRegister(uint8_t reg, uint8_t &value) {
  Wire.beginTransmission(TCA9554_ADDRESS);
  Wire.write(reg);
  if (Wire.endTransmission(false) != 0) {
    return false;
  }

  if (Wire.requestFrom(TCA9554_ADDRESS, static_cast<uint8_t>(1)) != 1) {
    return false;
  }

  value = Wire.read();
  return true;
}

void stopWithError(const char *message) {
  Serial.println(message);
  Serial.println("Check SDA=GPIO23, SCL=GPIO24 and board soldering.");
  while (true) {
    delay(1000);
  }
}

void setup() {
  Serial.begin(115200);
  delay(1000);
  Serial.println("TCA9554 IO expander test");

  Wire.begin(I2C_SDA_PIN, I2C_SCL_PIN, 100000);

  Wire.beginTransmission(TCA9554_ADDRESS);
  if (Wire.endTransmission() != 0) {
    stopWithError("FAIL: TCA9554 not found at I2C address 0x20.");
  }

  Serial.println("PASS: TCA9554 detected at I2C address 0x20.");

  if (!writeRegister(REG_POLARITY, 0x00) ||
      !writeRegister(REG_CONFIGURATION, 0x00) ||
      !writeRegister(REG_OUTPUT, 0x00)) {
    stopWithError("FAIL: Unable to configure TCA9554.");
  }

  Serial.println("EXT_IO1~EXT_IO6 will be driven HIGH one by one.");
  Serial.println("Use a multimeter or logic analyzer to observe the header pins.");
}

void loop() {
  for (uint8_t index = 0; index < ACCESSIBLE_EXT_IO_COUNT; ++index) {
    const uint8_t outputValue = static_cast<uint8_t>(1U << index);

    if (!writeRegister(REG_OUTPUT, outputValue)) {
      stopWithError("FAIL: Unable to write output register.");
    }

    uint8_t inputValue = 0;
    readRegister(REG_INPUT, inputValue);

    Serial.printf("EXT_IO%u HIGH; output=0x%02X, sampled input=0x%02X\n",
                  index + 1, outputValue, inputValue);
    delay(1000);
  }

  writeRegister(REG_OUTPUT, 0x00);
  Serial.println("All accessible EXT_IO outputs LOW.\n");
  delay(1000);
}
