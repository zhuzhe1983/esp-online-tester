# ESP32-C6-LCD-1.9

中文wiki链接: https://docs.waveshare.net/ESP32-C6-LCD-1.9<br>
Product English wiki link: https://docs.waveshare.com/ESP32-C6-LCD-1.9

This repository is compatible with the following models:

* ESP32-C6-LCD-1.9
* ESP32-C6-Touch-LCD-1.9

## Quick start / 快速开始

For the ESP32-C6-LCD-1.9 factory firmware and flashing instructions, see [firmware/](firmware/).
ESP32-C6-LCD-1.9 的出厂固件及烧录说明见 [firmware/](firmware/)。

# Arduino example Tools configuration
![alt text](<Tools Configuration.png>)

## Change log

### [1.0.0] 2026/03/10
- Includes examples of WiFi driver, ADC voltage measurement, attitude sensor driver, SD card driver, LVGL, etc.

## 更新日志

### [1.0.0] 2026/03/10
- 包含wifi驱动、adc电压测量、姿态传感器驱动、sd卡驱动、lvgl等示例。
