# ESP32-C6-LCD-0.85 Factory Firmware

[简体中文](README_ZH.md)

| File | Purpose |
| --- | --- |
| [`ESP32-C6-LCD-0.85_FactoryOnly_20260507.bin`](ESP32-C6-LCD-0.85_FactoryOnly_20260507.bin) | Restores the ESP32-C6-LCD-0.85 factory demo. |

Use esptool 5 or later. Open a terminal in this directory and replace `PORT` with the board's serial port. Back up your data before erasing the entire flash, which clears existing firmware, settings, and user data.

```sh
python -m esptool --chip esp32c6 --port PORT erase-flash
python -m esptool --chip esp32c6 --port PORT write-flash 0x0 ESP32-C6-LCD-0.85_FactoryOnly_20260507.bin
```

Reset the board and confirm that the factory demo starts. See the [product documentation](https://docs.waveshare.com/ESP32-C6-LCD-0.85) for connection and download-mode instructions.

The legacy files in [`examples/`](examples/) are identical to the example binaries in the ESP32-S3-LCD-0.85 repository. To run examples on ESP32-C6, build them from the [C6 example sources](../Example/).
