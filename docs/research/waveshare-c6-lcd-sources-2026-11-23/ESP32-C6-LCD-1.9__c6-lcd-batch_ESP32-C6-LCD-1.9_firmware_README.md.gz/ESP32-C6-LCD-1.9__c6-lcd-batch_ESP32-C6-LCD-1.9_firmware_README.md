# ESP32-C6-LCD-1.9 Factory Firmware

[简体中文](README_ZH.md)

| File | Purpose |
| --- | --- |
| [`ESP32-C6-LCD-1.9_FactoryOnly_20260312.bin`](ESP32-C6-LCD-1.9_FactoryOnly_20260312.bin) | Restores the ESP32-C6-LCD-1.9 factory demo. |

Connect the board with a USB data cable. Open a terminal in this directory, use esptool 5 or later, and replace `PORT` with the board's serial port.

Erasing the entire flash clears existing firmware, settings, and user data. Back up anything you need before proceeding.

```sh
python -m esptool --chip esp32c6 --port PORT erase-flash
python -m esptool --chip esp32c6 --port PORT write-flash 0x0 ESP32-C6-LCD-1.9_FactoryOnly_20260312.bin
```

After flashing, reset the board and check that the factory demo starts. For connection and download-mode instructions, see the [product documentation](https://docs.waveshare.com/ESP32-C6-LCD-1.9).
