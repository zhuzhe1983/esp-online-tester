# Waveshare ESP32-C6-LCD-0.85

[中文](README_ZH.md)

The ESP32-C6-LCD-0.85 is a compact development board based on the ESP32-C6. It features a 0.85-inch 128 × 128 color LCD, Wi-Fi 6 and Bluetooth 5 (LE) connectivity, together with onboard audio input/output, a TF card slot, programmable RGB LEDs, user buttons, and battery management. The board is suitable for developing miniature smart displays, voice interaction devices, IoT terminals, and other compact embedded applications.

- [Purchase Link](https://www.waveshare.com/esp32-c6-lcd-0.85.htm)
- [Documentation](https://docs.waveshare.com/ESP32-C6-LCD-0.85)

<img src="assets/ESP32-C6-LCD-0.85-EN-1.webp" alt="Waveshare ESP32-C6-LCD-0.85" width="500">

## Repository Structure

This repository provides sample programs, factory firmware, and hardware design files for the ESP32-C6-LCD-0.85.

```text
.
├── Example/         # Sample programs for Arduino and ESP-IDF
├── firmware/        # Factory firmware and prebuilt examples
├── hardware/        # Hardware schematics (PDF)
└── assets/          # Images used in the documentation
```

## Getting Started

For factory firmware and flashing instructions, see [`firmware/`](firmware/). Source code for Arduino and ESP-IDF is provided in [`Example/`](Example).

For development environment setup, flashing instructions, pin definitions, and detailed configuration, refer to the [documentation page](https://docs.waveshare.com/ESP32-C6-LCD-0.85).

## Contributing

We welcome contributions. Here's how you can help:

1. Fork the repository.
2. Create a new branch for your feature or bug fix.
3. Commit your changes with clear descriptions.
4. Submit a pull request for review.

## Issues and Support

Open an [issue](https://github.com/waveshareteam/ESP32-C6-LCD-0.85/issues) with detailed information, or contact the Waveshare team with your order number for technical support.

## License

Licensed under the Apache License 2.0. See the [LICENSE](LICENSE) file for details.

---

Thank you for using Waveshare Electronics products!
