# Waveshare ESP32-S3-LCD-0.85

[中文](README_ZH.md)

The ESP32-S3-LCD-0.85 is a compact, high-performance development board built around the ESP32-S3 (dual-core Xtensa LX7 @ 240 MHz, 8 MB PSRAM, 8 MB Flash) with 2.4 GHz Wi-Fi and Bluetooth 5 LE. It integrates a 0.85-inch 128 × 128 LCD, an ES8311 audio codec, a TF card slot, a user button, and eight WS2812 RGB LEDs, making it suitable for wearable devices, miniature information displays, audio applications, and IoT projects.

- [Purchase Link](https://www.waveshare.com/esp32-s3-lcd-0.85.htm)
- [Documentation](https://docs.waveshare.com/ESP32-S3-LCD-0.85)

<img src="assets/ESP32-S3-LCD-0.85-1.webp" alt="Waveshare ESP32-S3-LCD-0.85" width="500">

## Repository Structure

This repository provides sample programs, factory firmware, and hardware design files for the ESP32-S3-LCD-0.85.

```text
.
├── example/         # Sample programs for ESP-IDF and Arduino
├── firmware/        # Factory firmware and prebuilt examples
├── hardware/        # Hardware design files and schematics
└── assets/          # Images used in documentation
```

## Getting Started

For factory firmware and flashing instructions, see [`firmware/`](firmware/). For development setup and pin mappings, see the [product documentation](https://docs.waveshare.com/ESP32-S3-LCD-0.85).

## Contributing

We welcome contributions! Here's how you can help:

1. Fork the repository.
2. Create a new branch for your feature or bug fix.
3. Commit your changes with clear descriptions.
4. Submit a pull request for review.

## Issues and Support

Open an [issue](https://github.com/waveshareteam/ESP32-S3-LCD-0.85/issues) with detailed information, or contact the Waveshare team with your order number for technical support.

## License

Licensed under the Apache License 2.0. See the [LICENSE](LICENSE) file for details.

---

Thank you for using Waveshare Electronics products!
