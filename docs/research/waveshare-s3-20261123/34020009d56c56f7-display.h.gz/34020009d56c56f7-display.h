/*
 * SPDX-FileCopyrightText: 2023-2025 Espressif Systems (Shanghai) CO LTD
 *
 * SPDX-License-Identifier: Apache-2.0
 */

/**
 * @file
 * @brief BSP LCD
 *
 * This file offers API for basic LCD control.
 * It is useful for users who want to use the LCD without the default Graphical Library LVGL.
 *
 * For standard LCD initialization with LVGL graphical library, you can call all-in-one function bsp_display_start().
 */

#pragma once
#include "esp_lcd_types.h"

/** @defgroup g04_display Display and Touch
 *  @brief Display BSP API
 *  @{
 */

/* LCD color formats */
#define ESP_LCD_COLOR_FORMAT_RGB565    (1)
#define ESP_LCD_COLOR_FORMAT_RGB888    (2)

/* LCD display color format */
#define BSP_LCD_COLOR_FORMAT        (ESP_LCD_COLOR_FORMAT_RGB565)
/* LCD display color bytes endianess */
#define BSP_LCD_BIGENDIAN           (1)
/* LCD display color bits */
#define BSP_LCD_BITS_PER_PIXEL      (16)
/* LCD display color space */
#define BSP_LCD_COLOR_SPACE         (LCD_RGB_ELEMENT_ORDER_RGB)
/* LCD definition */

#if CONFIG_BSP_LCD_SIZE_2INCH || CONFIG_BSP_LCD_SIZE_2_8INCH
#define BSP_LCD_H_RES              (320)
#define BSP_LCD_V_RES              (240)
#elif CONFIG_BSP_LCD_SIZE_3_5INCH
#define BSP_LCD_H_RES              (320)
#define BSP_LCD_V_RES              (480)
#elif  CONFIG_BSP_LCD_SIZE_1_83INCH
#define BSP_LCD_H_RES              (284)
#define BSP_LCD_V_RES              (240)
#endif


#ifdef __cplusplus
extern "C" {
#endif

/**
 * @brief BSP display configuration structure
 *
 */
typedef struct {
    int max_transfer_sz;    /*!< Maximum transfer size, in bytes. */
} bsp_display_config_t;

/**
 * @brief Create new display panel
 *
 * For maximum flexibility, this function performs only reset and initialization of the display.
 * You must turn on the display explicitly by calling esp_lcd_panel_disp_on_off().
 * The display's backlight is not turned on either. You can use bsp_display_backlight_on/off(),
 * bsp_display_brightness_set() (on supported boards) or implement your own backlight control.
 *
 * If you want to free resources allocated by this function, you can use esp_lcd API, ie.:
 *
 * \code{.c}
 * esp_lcd_panel_del(panel);
 * esp_lcd_panel_io_del(io);
 * spi_bus_free(spi_num_from_configuration);
 * \endcode
 *
 * @param[in]  config    display configuration
 * @param[out] ret_panel esp_lcd panel handle
 * @param[out] ret_io    esp_lcd IO handle
 * @return
 *      - ESP_OK         On successa
 *      - Else           esp_lcd failure
 */
esp_err_t bsp_display_new(const bsp_display_config_t *config, esp_lcd_panel_handle_t *ret_panel, esp_lcd_panel_io_handle_t *ret_io);

/**
 * @brief Turn on display backlight
 *
 * Backlight is controlled with IO expander TCA9554.
 *
 * @return
 *      - ESP_OK                On success
 *      - Else                  Failure to initialize IO expander or set backlight level
 */
esp_err_t bsp_display_backlight_on(void);

/**
 * @brief Turn off display backlight
 *
 * Backlight is controlled with IO expander TCA9554.
 *
 * @return
 *      - ESP_OK                On success
 *      - Else                  Failure to initialize IO expander or set backlight level
 */
esp_err_t bsp_display_backlight_off(void);

/* Brightness functions are not implemented on this board.
   These functions are here to provide consistent API with other Board Support Packages */
esp_err_t bsp_display_brightness_init(void);
esp_err_t bsp_display_brightness_set(int brightness_percent);

#ifdef __cplusplus
}
#endif

/** @} */ // end of display
