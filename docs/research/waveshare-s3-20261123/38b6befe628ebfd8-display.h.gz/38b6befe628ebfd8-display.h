#pragma once

#include "esp_lcd_types.h"
#include "sdkconfig.h"

#ifdef __cplusplus
extern "C" {
#endif

/*=============================================================================
 *  Color format definitions (common)
 *===========================================================================*/
#define ESP_LCD_COLOR_FORMAT_RGB565    (1)
#define ESP_LCD_COLOR_FORMAT_RGB888    (2)

/*=============================================================================
 *  LCD hardware parameters (selected by Kconfig)
 *  Listed in increasing screen size order.
 *===========================================================================*/
/* Resolution selection based on LCD type */
#if defined(CONFIG_BSP_LCD_TYPE_240X240_1_28_INCH)      
    #define BSP_LCD_H_RES              (240)
    #define BSP_LCD_V_RES              (240)
    #define BSP_LCD_SPI_CLK_HZ         (40 * 1000 * 1000)
#elif defined(CONFIG_BSP_LCD_TYPE_240X240_1_54_INCH)
    #define BSP_LCD_H_RES              (240)
    #define BSP_LCD_V_RES              (240)
    #define BSP_LCD_SPI_CLK_HZ         (40 * 1000 * 1000)
#elif defined(CONFIG_BSP_LCD_TYPE_240X280_1_69_INCH)      
    #define BSP_LCD_H_RES              (240)
    #define BSP_LCD_V_RES              (280)
    #define BSP_LCD_SPI_CLK_HZ         (40 * 1000 * 1000)
#elif defined(CONFIG_BSP_LCD_TYPE_240X284_1_83_INCH)
    #define BSP_LCD_H_RES              (240)
    #define BSP_LCD_V_RES              (284)
    #define BSP_LCD_SPI_CLK_HZ         (40 * 1000 * 1000)
#elif defined(CONFIG_BSP_LCD_TYPE_170X320_1_9_INCH)      
    #define BSP_LCD_H_RES              (170)
    #define BSP_LCD_V_RES              (320)
    #define BSP_LCD_SPI_CLK_HZ         (40 * 1000 * 1000)
#elif defined(CONFIG_BSP_LCD_TYPE_240X320_2_0_INCH)
    #define BSP_LCD_H_RES              (240)
    #define BSP_LCD_V_RES              (320)
    #define BSP_LCD_SPI_CLK_HZ         (40 * 1000 * 1000)
#elif defined(CONFIG_BSP_LCD_TYPE_240X320_2_8_INCH)
    #define BSP_LCD_H_RES              (240)
    #define BSP_LCD_V_RES              (320)
    #define BSP_LCD_SPI_CLK_HZ         (40 * 1000 * 1000)  
#elif defined(CONFIG_BSP_LCD_TYPE_320X480_3_5_INCH)
    #define BSP_LCD_H_RES              (320)
    #define BSP_LCD_V_RES              (480)
    #define BSP_LCD_SPI_CLK_HZ         (80 * 1000 * 1000)  
#elif defined(CONFIG_BSP_LCD_TYPE_320X480_3_5_INCH_RPI)
    #define BSP_LCD_H_RES              (320)
    #define BSP_LCD_V_RES              (480)
    #define BSP_LCD_SPI_CLK_HZ         (40 * 1000 * 1000)  
#else
    /* Fallback to direct Kconfig values (if defined) */
    #ifndef BSP_LCD_H_RES
        #define BSP_LCD_H_RES          CONFIG_BSP_LCD_H_RES
    #endif
    #ifndef BSP_LCD_V_RES
        #define BSP_LCD_V_RES          CONFIG_BSP_LCD_V_RES
    #endif
    #ifndef BSP_LCD_SPI_CLK_HZ
        #define BSP_LCD_SPI_CLK_HZ     (20 * 1000 * 1000)  /* Safe default */
    #endif
#endif

/* Color format selection */
#if CONFIG_BSP_LCD_COLOR_FORMAT_RGB888
    #define BSP_LCD_COLOR_FORMAT        (ESP_LCD_COLOR_FORMAT_RGB888)
    #define BSP_LCD_BITS_PER_PIXEL      (24)
#else
    #define BSP_LCD_COLOR_FORMAT        (ESP_LCD_COLOR_FORMAT_RGB565)
    #define BSP_LCD_BITS_PER_PIXEL      (16)
#endif

#define BSP_LCD_BIGENDIAN               (0)                 /* Little endian */
#define BSP_LCD_COLOR_SPACE             (ESP_LCD_COLOR_SPACE_RGB)

/*=============================================================================
 *  Data structures
 *===========================================================================*/
/**
 * @brief BSP display configuration structure
 *
 * Passed to bsp_display_new() to customize LCD initialization.
 * Set max_transfer_sz to 0 for default size (DMA buffer size).
 */
typedef struct {
    int max_transfer_sz;        /*!< Maximum transfer size in bytes (DMA buffer) */
} bsp_display_config_t;

/**
 * @brief BSP LCD handles structure
 *
 * Contains all handles related to the LCD panel.
 * For non-MIPI displays, only `io` and `panel` are used.
 */
typedef struct {
    esp_lcd_panel_io_handle_t   io;         /*!< LCD panel IO handle (communication) */
    esp_lcd_panel_handle_t      panel;      /*!< LCD panel handle (color data) */
    void                       *priv;       /*!< Reserved for future use */
} bsp_lcd_handles_t;

/*=============================================================================
 *  Function declarations
 *===========================================================================*/
/**
 * @brief Create a new LCD panel
 *
 * Initializes the LCD hardware (reset, init sequence) but does not turn on
 * the display or backlight. You must explicitly call esp_lcd_panel_disp_on_off()
 * and bsp_display_backlight_on() after creation.
 *
 * @param[in]  config    Display configuration (can be NULL for defaults)
 * @param[out] ret_panel LCD panel handle
 * @param[out] ret_io    LCD panel IO handle
 * @return
 *      - ESP_OK         Success
 *      - Else           Error code
 */
esp_err_t bsp_display_new(const bsp_display_config_t *config,
                          esp_lcd_panel_handle_t *ret_panel,
                          esp_lcd_panel_io_handle_t *ret_io);

/**
 * @brief Create a new LCD panel with all handles in one structure
 *
 * Similar to bsp_display_new() but returns all handles in a single structure.
 *
 * @param[in]  config     Display configuration (can be NULL for defaults)
 * @param[out] ret_handles Structure containing io and panel handles
 * @return
 *      - ESP_OK         Success
 *      - Else           Error code
 */
esp_err_t bsp_display_new_with_handles(const bsp_display_config_t *config,
                                       bsp_lcd_handles_t *ret_handles);

/**
 * @brief Draw bit-level test stripes on the LCD panel
 *
 * This function draws vertical stripes corresponding to each bit of the pixel
 * color depth (e.g., 16 stripes for RGB565, 24 stripes for RGB888). Each stripe
 * activates only one bit of the pixel data, used to verify that all bits of the
 * LCD display and SPI/DMA transmission are working correctly.
 *
 * @param[in] panel_handle Handle of the LCD panel to draw on
 *
 * @note This function uses small block buffers to avoid large memory allocations
 *       and prevent SPI transmission queue overflow.
 * @note The color format must match the panel configuration (RGB565/RGB888).
 */
void lcd_draw_bit_stripes(esp_lcd_panel_handle_t panel_handle);

/**
 * @brief Get the initialized LCD panel handle
 *
 * Retrieves the static LCD panel handle that was created and initialized by
 * bsp_display_new() or bsp_display_new_with_handles(). This allows other files
 * (like main.c) to access the panel handle without exposing static variables.
 *
 * @return esp_lcd_panel_handle_t
 *      - Valid handle if LCD was initialized successfully
 *      - NULL if LCD has not been initialized yet
 *
 * @note This function is thread-safe and can be called at any time after
 *       bsp_display_start() or bsp_display_new_with_handles().
 */
esp_lcd_panel_handle_t bsp_display_get_panel_handle(void);

/**
 * @brief Initialize backlight PWM
 *
 * Must be called before using any backlight control functions.
 * @return
 *      - ESP_OK         Success
 *      - Else           Error code
 */
esp_err_t bsp_display_brightness_init(void);

/**
 * @brief Set backlight brightness
 *
 * @param[in] brightness_percent Brightness in percent (0..100)
 * @return
 *      - ESP_OK         Success
 *      - Else           Error code
 */
esp_err_t bsp_display_brightness_set(int brightness_percent);

/**
 * @brief Turn on backlight (full brightness)
 *
 * @return
 *      - ESP_OK         Success
 *      - Else           Error code
 */
esp_err_t bsp_display_backlight_on(void);

/**
 * @brief Turn off backlight
 *
 * @return
 *      - ESP_OK         Success
 *      - Else           Error code
 */
esp_err_t bsp_display_backlight_off(void);

#ifdef __cplusplus
}
#endif