# ESP32-S3-LCD-0.85 出厂固件

[English](README.md)

| 文件 | 用途 |
| --- | --- |
| [`ESP32-S3-LCD-0.85_FactoryOnly_20260320.bin`](ESP32-S3-LCD-0.85_FactoryOnly_20260320.bin) | 恢复 ESP32-S3-LCD-0.85 的出厂演示。 |

使用 esptool 5 或更新版本。在本目录打开终端，将 `PORT` 替换为开发板的串口。整片擦除 Flash 会清除原有固件、设置和用户数据，请提前备份。

```sh
python -m esptool --chip esp32s3 --port PORT erase-flash
python -m esptool --chip esp32s3 --port PORT write-flash 0x0 ESP32-S3-LCD-0.85_FactoryOnly_20260320.bin
```

烧录完成后复位开发板，确认出厂演示正常启动。连接和下载模式请参考[产品文档](https://docs.waveshare.net/ESP32-S3-LCD-0.85)。

原有预编译示例位于 [`examples/`](examples/)。
