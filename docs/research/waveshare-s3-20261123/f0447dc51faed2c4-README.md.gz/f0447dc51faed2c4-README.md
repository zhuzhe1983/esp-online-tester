# ESP32-S3-LCD-0.85 Factory Firmware

[简体中文](README_ZH.md)

| File | Purpose |
| --- | --- |
| [`ESP32-S3-LCD-0.85_FactoryOnly_20260320.bin`](ESP32-S3-LCD-0.85_FactoryOnly_20260320.bin) | Restores the ESP32-S3-LCD-0.85 factory demo. |

Use esptool 5 or later. Open a terminal in this directory and replace `PORT` with the board's serial port. Back up your data before erasing the entire flash, which clears existing firmware, settings, and user data.

```sh
python -m esptool --chip esp32s3 --port PORT erase-flash
python -m esptool --chip esp32s3 --port PORT write-flash 0x0 ESP32-S3-LCD-0.85_FactoryOnly_20260320.bin
```

Reset the board and confirm that the factory demo starts. See the [product documentation](https://docs.waveshare.com/ESP32-S3-LCD-0.85) for connection and download-mode instructions.

The original prebuilt examples are available in [`examples/`](examples/).
