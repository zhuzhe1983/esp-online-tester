#define uS_TO_S_FACTOR 1000000ULL  /* Conversion factor for micro seconds to seconds */
#define TIME_TO_SLEEP  5        /* Time ESP32 will go to sleep (in seconds) */
#define CALIBRATE_ONE(cali_clk) calibrate_one(cali_clk, #cali_clk)
