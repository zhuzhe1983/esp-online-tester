#define W5500_CS     14  // Chip Select (CS)
#define W5500_RST     9  // Reset (RST)
#define W5500_INT    10  // Interrupt (INT) - optional
#define W5500_MISO   12  // MISO
#define W5500_MOSI   11  // MOSI
  SPI.begin(W5500_SCK, W5500_MISO, W5500_MOSI, W5500_CS);
  Ethernet.init(W5500_CS);
