#define CAMERA_MODEL_ESP_EYE  // Has PSRAM
  pinMode(CAM_ENABLE, OUTPUT);   // Configure CAM_ENABLE pin as output
  digitalWrite(CAM_ENABLE, LOW); // Ensure CAM_ENABLE is off at startup
