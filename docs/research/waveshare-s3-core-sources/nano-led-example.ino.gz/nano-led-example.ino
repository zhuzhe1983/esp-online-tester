void setup() {


pinMode(14, OUTPUT);

pinMode(15, OUTPUT);

pinMode(16, OUTPUT);
pinMode(13, OUTPUT); }



void loop() {

//here current flows through  illuminating red led in the RGB LED

digitalWrite(14, LOW);

digitalWrite(15, HIGH);

digitalWrite(16, HIGH);

digitalWrite(13, HIGH);

delay(500);

//here current flows through  illuminating green led in the RGB LED

digitalWrite(14, HIGH);

digitalWrite(15, LOW);

digitalWrite(16, HIGH);

delay(500);

//here current flows through  illuminating blue led in the RGB LED

digitalWrite(14,HIGH );

digitalWrite(15, HIGH);

digitalWrite(16, LOW);

digitalWrite(13, LOW);
// digitalWrite(LED_RED, LOW); //red
// digitalWrite(LED_GREEN, LOW); //green
// digitalWrite(LED_BLUE, LOW); //blue

delay(500);

//Further mixture of colours can be crteated by keeping any two pins HIGH at the same time

}