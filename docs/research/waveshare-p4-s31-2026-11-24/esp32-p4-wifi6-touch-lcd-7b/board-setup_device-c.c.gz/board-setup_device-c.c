/*
 * SPDX-FileCopyrightText: 2026 Espressif Systems (Shanghai) CO., LTD
 * SPDX-License-Identifier: LicenseRef-Espressif-Modified-MIT
 *
 * See LICENSES/LicenseRef-Espressif-Modified-MIT.txt for details.
 */

/*
 * NOTE: This file is auto-generated and is only a template implementation of setup_device.
 * Manual review and debugging may be required before it can compile and run on real hardware.
 */

#include "esp_err.h"
#include "esp_log.h"
#include "esp_board_manager_includes.h"

#if __has_include(<esp_lcd_ek79007.h>)
#define HAS_EK79007  1
#include "esp_lcd_ek79007.h"
#endif  /* __has_include(<esp_lcd_ek79007.h>) */

#if __has_include(<esp_lcd_touch_gt911.h>)
#define HAS_GT911  1
#include "esp_lcd_touch_gt911.h"
#endif  /* __has_include(<esp_lcd_touch_gt911.h>) */

static const char *TAG = "ESP32_P4_WIFI6_TOUCH_LCD_7B_SETUP_DEVICE";

#if defined(HAS_EK79007)
__attribute__((weak)) esp_err_t lcd_dsi_panel_factory_entry_t(esp_lcd_dsi_bus_handle_t dsi_handle,
                                                              dev_display_lcd_config_t *lcd_cfg,
                                                              dev_display_lcd_handles_t *lcd_handles)
{
    if (dsi_handle == NULL || lcd_cfg == NULL || lcd_handles == NULL || lcd_handles->io_handle == NULL) {
        return ESP_ERR_INVALID_ARG;
    }

    ek79007_vendor_config_t vendor_config = {
        .mipi_config = {
            .dsi_bus = dsi_handle,
            .dpi_config = &lcd_cfg->sub_cfg.dsi.dpi_config,
            .lane_num = 2,
        },
    };
    esp_lcd_panel_dev_config_t panel_cfg = {
        .reset_gpio_num = lcd_cfg->sub_cfg.dsi.reset_gpio_num,
        .rgb_ele_order = lcd_cfg->rgb_ele_order,
        .bits_per_pixel = lcd_cfg->bits_per_pixel,
        .data_endian = lcd_cfg->data_endian,
        .flags = {
            .reset_active_high = lcd_cfg->sub_cfg.dsi.reset_active_high,
        },
        .vendor_config = &vendor_config,
    };
    esp_err_t ret = esp_lcd_new_panel_ek79007(lcd_handles->io_handle, &panel_cfg, &lcd_handles->panel_handle);
    if (ret != ESP_OK) {
        ESP_LOGE(TAG, "Failed to create ek79007 panel: %s", esp_err_to_name(ret));
        return ret;
    }

    return ESP_OK;
}
#endif  /* defined(HAS_EK79007) */

#if defined(HAS_GT911)
__attribute__((weak)) esp_err_t lcd_touch_factory_entry_t(esp_lcd_panel_io_handle_t io,
                                                          const esp_lcd_touch_config_t *touch_dev_config,
                                                          esp_lcd_touch_handle_t *ret_touch)
{
    esp_err_t ret = esp_lcd_touch_new_i2c_gt911(io, touch_dev_config, ret_touch);
    if (ret != ESP_OK) {
        ESP_LOGE(TAG, "Failed to create gt911 touch driver: %s", esp_err_to_name(ret));
        return ret;
    }

    return ESP_OK;
}
#endif  /* defined(HAS_GT911) */
